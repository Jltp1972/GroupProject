package finalProject;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;


@SuppressWarnings("serial")
public class AccountInformation extends JFrame {
	public static void main(String[] args) {		
	}

		JLabel welcome = new JLabel("<html><b COLOR=PURPLE>Detailed Account Information</b>");
		JPanel panel = new JPanel();
		JLabel FName = new JLabel("First Name :");
		JLabel LName = new JLabel("Last Name :");
		JLabel EMail = new JLabel("Email :");
		JLabel PWord = new JLabel("Password :");

	AccountInformation(){
		super();
		setSize(300,270);
		setLocation(500,280);
		panel.setLayout (null); 

		welcome.setBounds(31,11,232,45);
		welcome.setFont(new Font("Tahoma", Font.BOLD, 15));
		panel.add(welcome);
		FName.setBounds(31,51,232,45);
		FName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(FName);		
		LName.setBounds(31,81,232,45);
		LName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(LName);		
		EMail.setBounds(61,111,232,45);
		EMail.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(EMail);
		PWord.setBounds(38,141,232,45);
		PWord.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(PWord);

		getContentPane().add(panel);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	}
	
