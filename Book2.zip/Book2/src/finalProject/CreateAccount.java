package finalProject;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;


@SuppressWarnings("serial")
public class CreateAccount extends JFrame {
	public static void main(String[] args) {		
	}	
		JPanel panel = new JPanel();
		JLabel welcome = new JLabel("<html><b COLOR=PURPLE>Create Account</b>");
		JLabel FName = new JLabel("First Name :");
		JLabel LName = new JLabel("Last Name :");
		JLabel EMail = new JLabel("Email :");
		JLabel PWord = new JLabel("Password :");
		JButton btnCreateAct = new JButton("Create account");
		JPasswordField pass = new JPasswordField(15);
		JTextField FirstNtext = new JTextField(15);
		JTextField LastNtext = new JTextField(15);
		JTextField Emailtext = new JTextField(15);

	CreateAccount(){
		super();
		setSize(300,270);
		setLocation(500,280);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		panel.setLayout (null); 
		// set all bounds, fonts, and add to panel button,labels & txtFields
		welcome.setBounds(85,11,232,45);
		welcome.setFont(new Font("Tahoma", Font.BOLD, 15));
		panel.add(welcome);		
		FName.setBounds(31,51,232,45);
		FName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(FName);		
		LName.setBounds(31,81,232,45);
		LName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(LName);		
		EMail.setBounds(61,111,232,45);
		EMail.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(EMail);
		PWord.setBounds(38,141,232,45);
		PWord.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.add(PWord);				
		pass.setBounds(100,155,150,20);
		panel.add(pass);
		FirstNtext.setBounds(100,125,150,20);
		panel.add(FirstNtext);
		LastNtext.setBounds(100,95,150,20);
		panel.add(LastNtext);
		Emailtext.setBounds(100,65,150,20);
		panel.add(Emailtext);
		btnCreateAct.setBounds(70, 194, 140, 25);
		btnCreateAct.setFont(new Font("Tahoma", Font.BOLD, 12));
		panel.add(btnCreateAct);
		
		getContentPane().add(panel);

		
		btnCreateAct.addActionListener(new ActionListener() {
			
	public void actionPerformed(ActionEvent ae) {
			// create action to save password and other info
			// to account information and able to login...
}});
		}
	}

	
