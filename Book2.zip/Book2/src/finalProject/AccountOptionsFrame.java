package finalProject;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

@SuppressWarnings("serial")
public class AccountOptionsFrame extends JFrame {
	
	public static void main(String[] args) {
	}
		JLabel welcome = new JLabel("<html><b COLOR=PURPLE>Welcome to our book rental database!</b>");
		JButton btnAccountInformation = new JButton("Account Information");
		JButton btnBookList = new JButton("Browse Library");
		JPanel panel = new JPanel();

		AccountOptionsFrame(){
		super();
		setSize(320,200);
		setLocation(470,280);
		panel.setLayout (null); 

		welcome.setBounds(10,11,290,45);
		welcome.setFont(new Font("Tahoma", Font.BOLD, 15));
		panel.add(welcome);

		getContentPane().add(panel);
		btnAccountInformation.setBounds(70, 60, 157, 23);
		panel.add(btnAccountInformation);
		btnBookList.setBounds(85, 108, 129, 23);
		panel.add(btnBookList);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		btnAccountInformation.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent ae){
			AccountInformation ai = new AccountInformation();
		}}); // end of accountOptionsFrame components added
		
		btnBookList.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent ae){
				try {
					BookStoreGUI bl = new BookStoreGUI();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}}); // end of bookList components added
	}
} // end of class


